from Funcao.Simplex import SimplexExE
print("----------------------------------------------")
print("\t Metodo de Simplex")
print("----------------------------------------------")
SimplexExE()
# Sempre iniciar pela main