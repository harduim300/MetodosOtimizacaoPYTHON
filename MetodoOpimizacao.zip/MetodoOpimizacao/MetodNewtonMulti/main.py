from Funcao.Newton import NewtonExE
print("----------------------------------------------")
print("\t Metodo de Newton")
print("----------------------------------------------")
NewtonExE()
# Sempre iniciar pela main