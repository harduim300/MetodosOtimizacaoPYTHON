from Funcao.HookeJeeve import HookeJeevesExE
print("----------------------------------------------")
print("\t Metodo de Hooke-Jeeves")
print("----------------------------------------------")
HookeJeevesExE()