from Funcao.Newton import NewtonExe
print("----------------------------------------------")
print("\t Metodo de Newton")
print("----------------------------------------------")
NewtonExe()