from Funcao.Aureo import AureoExe
print("----------------------------------------------")
print("\t Metodo da Secao Aurea")
print("----------------------------------------------")
AureoExe()