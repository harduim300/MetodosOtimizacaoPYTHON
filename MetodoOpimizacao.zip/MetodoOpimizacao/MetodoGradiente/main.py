from Funcao.Gradiente import GradienteExE
print("----------------------------------------------")
print("\t Metodo de Gradiente")
print("----------------------------------------------")
GradienteExE()