from Funcao.Rossenbrock import RossenbrockExE
print("----------------------------------------------")
print("\t Metodo de RossenBrock")
print("----------------------------------------------")
RossenbrockExE()