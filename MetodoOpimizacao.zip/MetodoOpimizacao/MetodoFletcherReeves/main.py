from Funcao.Reeves import ReevesExE
print("----------------------------------------------")
print("\t Metodo de Fletcher-Reeves")
print("----------------------------------------------")
ReevesExE()
# Sempre iniciar pela main